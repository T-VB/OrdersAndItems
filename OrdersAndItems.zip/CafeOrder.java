import java.util.ArrayList;

public class CafeOrder {

    public String name; 
    public double total;
    public boolean ready;
    public ArrayList<CafeItem> items = new ArrayList<CafeItem>();
    
}