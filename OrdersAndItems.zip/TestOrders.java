import java.util.ArrayList;
public class TestOrders {
    public static void main(String[] args) {

    //create menu items/instances for each CafeItem
    CafeItem item1 = new CafeItem(); //order variable = item1, item2...
    item1.name = "mocha";
    item1.price = 3.75;
    
    CafeItem item2 = new CafeItem();
    item2.name = "latte";
    item2.price = 4.25;

    CafeItem item3 = new CafeItem();
    item3.name = "drip coffe";
    item3.price = 2.5;

    CafeItem item4 = new CafeItem();
    item4.name = "capucinno";
    item4.price = 3.25;
    
    CafeOrder order1 = new CafeOrder(); //create order variables and instantiate as an obj (order1,2...)
    System.out.println(order1.total);
    order1.name = "Tyler";

    CafeOrder order2 = new CafeOrder();
    order2.name = "Champ";

    CafeOrder order3 = new CafeOrder();
    order3.name = "Shiloh";

    CafeOrder order4 = new CafeOrder();
    order4.name = "Felix";
    

    //Add item1 to order2's arraylist and add to order's total
    order2.items.add(item1);
    order2.total += item1.price;
    System.out.println(order2.total);

    //order3 ordered a capucinno, add to their order list and total tab
    order3.items.add(item4);
    order3.total += item4.price;
    System.out.println(order3.total);

    //order4 ordered a latte
    order4.items.add(item2);
    order4.total += item2.price;
    System.out.println(order4.total);

    //Tyler's order is now ready
    order1.ready = true;
    System.out.printf("Ready: %s\n", order4.ready);

    //Felix orders two more lattes
    order4.items.add(item2);
    order4.total += item2.price *2;
    System.out.println(order4.total);
    //Shiloh's order is now ready
    order3.ready = true;
    System.out.printf("Ready: %s \n", order3.ready);
        // Use this example code to test various orders' updates
        System.out.printf("Name: %s\n", order1.name);
        System.out.printf("Total: %s\n", order1.total);
        System.out.printf("Ready: %s\n", order1.ready);
    }
}
