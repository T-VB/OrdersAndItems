public class CafeItem {

public String name;
public double price;

}